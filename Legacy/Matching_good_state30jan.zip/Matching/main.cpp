#include "imageProcessing.cpp"

  
/// Global variables
Mat image;
Mat patch;
Mat art;
Mat art_ref;
Mat art_ref_tuned;
orineted_position oriented_pos;
 
/** @function main */
int main( int argc, char** argv )
 {	 
	/// Load the images
	image = imread( argv[1], 1 );
	image = convert_BGRtoBGRA(image);
	patch = imread( argv[2], 1 );	
	patch = convert_BGRtoBGRA(patch);
	patch= Rotate(patch, -17);	
	
	/// init the ART mats
	art_ref = copyPolygon(image);
	art_ref_tuned = copyPolygon(image);
	art = Mat::zeros( image.rows, image.cols, CV_8UC4 );
	art = Scalar( 255, 255, 255, 1 );	
		
	//while(1)
	{	
		//patch = generatePoly(17);	
		

		
		/// declare container of filter output	
		vector <vector < vector <double> > > result_scores;
			
		/// Run the template matching filter
		clock_t begin_filter = clock(); 	
		double minimum_error=0;
		result_scores = filter_fast(image,patch,  oriented_pos ,minimum_error);		
		clock_t end_filter = clock();
				
		/// Run the Fine Tune template matching filter
		clock_t begin_tunefilter = clock(); 	
		double new_minimum_error=0;
		orineted_position new_oriented_pos;
		filter_fine_tune(	image,
							patch, 
							oriented_pos, 
							new_oriented_pos ,
							new_minimum_error);	
		clock_t end_tunefilter = clock();
		
		Mat rotated_patch = Rotate(patch, oriented_pos.r);
		Mat new_rotated_patch = Rotate(patch, new_oriented_pos.r);
			
		/// Drawing in ART mats
		clock_t begin_draw = clock(); 
		//if(min<100)
		{
			for(int i = oriented_pos.x; i<(oriented_pos.x+rotated_patch.cols) ; i++ )
			{
				for(int j= oriented_pos.y ; j <(oriented_pos.y+rotated_patch.rows); j ++)
				{
					if(rotated_patch.at<Vec4b>(Point(i-oriented_pos.x,j-oriented_pos.y))[3] == 1)
					{
						art_ref.at<Vec4b>(Point(i,j))[0] = 
							rotated_patch.at<Vec4b>(Point(i-oriented_pos.x,j-oriented_pos.y))[0];
						art_ref.at<Vec4b>(Point(i,j))[1] = 
							rotated_patch.at<Vec4b>(Point(i-oriented_pos.x,j-oriented_pos.y))[1];
						art_ref.at<Vec4b>(Point(i,j))[2] = 
							rotated_patch.at<Vec4b>(Point(i-oriented_pos.x,j-oriented_pos.y))[2];
					} 
				}
			} 
		} 
		{
			for(int i = new_oriented_pos.x; i<(new_oriented_pos.x+new_rotated_patch.cols) ; i++ )
			{
				for(int j= new_oriented_pos.y ; j <(new_oriented_pos.y+new_rotated_patch.rows); j ++)
				{
					if(new_rotated_patch.at<Vec4b>(Point(i-new_oriented_pos.x,j-new_oriented_pos.y))[3] == 1)
					{
						art_ref_tuned.at<Vec4b>(Point(i,j))[0] = 
							new_rotated_patch.at<Vec4b>(Point(i-new_oriented_pos.x,j-new_oriented_pos.y))[0];
						art_ref_tuned.at<Vec4b>(Point(i,j))[1] = 
							new_rotated_patch.at<Vec4b>(Point(i-new_oriented_pos.x,j-new_oriented_pos.y))[1];
						art_ref_tuned.at<Vec4b>(Point(i,j))[2] = 
							new_rotated_patch.at<Vec4b>(Point(i-new_oriented_pos.x,j-new_oriented_pos.y))[2];
					} 
				}
			} 
		}
		clock_t end_draw = clock(); 
		
			
		/// Compute times
		double filter_elapsed_secs = double(end_filter - begin_filter) / CLOCKS_PER_SEC;
		double tune_filter_elapsed_secs = double(end_tunefilter - begin_tunefilter) / CLOCKS_PER_SEC;
		double draw_elapsed_secs = double(end_draw - begin_draw) / CLOCKS_PER_SEC;
		
		 
		/// Print 
		cout<< "----------------------------------"<< endl;
		cout<< "DONE"<< endl;
		cout<< "Image Area: "<<patchArea(image) << endl;
		cout<< "Patch Area: "<<patchArea(patch)<< endl;
		cout<< "----------------------------------"<< endl;
		cout<< "Found in x: " << oriented_pos.x << "  y: " << 
			oriented_pos.y << " at rotation: " << oriented_pos.r << endl; 
		
		cout<< "Estimated Error: "<<minimum_error << endl;
		cout<< "Filter Processing Time: "<<filter_elapsed_secs<< " sec"<<  endl;
		//cout<< "Draw Time: "<<draw_elapsed_secs<< " sec"<<  endl;
		cout<< "----------------------------------"<< endl;
		cout<< "Tuned Found in x: " << new_oriented_pos.x << "  y: " << 
			new_oriented_pos.y << " at rotation: " << new_oriented_pos.r << endl; 		
		cout<< "Tuned Estimated Error: "<<new_minimum_error << endl;
		cout<< "Tuned Filter Processing Time: "<<tune_filter_elapsed_secs<< " sec"<<  endl;
		  
		
		/// Display all
		imshow( "Source", image );
		imshow( "Patch", patch );
		//imshow("art", (art));
		imshow("art_ref", (art_ref));
		imshow("art_ref_tuned", (art_ref_tuned));
		imshow("trans", (transparency_check(rotated_patch)));
		
		
		waitKey(0);
	
	} /// end of while(1) loop
	
	
	return 0; 
  }   
